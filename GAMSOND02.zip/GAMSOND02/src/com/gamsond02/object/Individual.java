package com.gamsond02.object;

import java.util.ArrayList;

public class Individual {
	private int ID;
	private double fitness;
	ArrayList<WorkingBackup> listWorkingBackup;
	public final int getID() {
		return ID;
	}
	public final void setID(int iD) {
		ID = iD;
	}
	public final double getFitness() {
		return fitness;
	}
	public final void setFitness(double fitness) {
		this.fitness = fitness;
	}
	public final ArrayList<WorkingBackup> getListWorkingBackup() {
		return listWorkingBackup;
	}
	public final void setListWorkingBackup(
			ArrayList<WorkingBackup> listWorkingBackup) {
		this.listWorkingBackup = listWorkingBackup;
	}
	public Individual(int iD, double fitness,
			ArrayList<WorkingBackup> listWorkingBackup) {
		super();
		ID = iD;
		this.fitness = fitness;
		this.listWorkingBackup = listWorkingBackup;
	}
	
	
}
