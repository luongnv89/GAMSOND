package com.gamsond02.object;

import java.util.ArrayList;

/**
 * Present a physical path of a request
 * 
 * */
public class Gen {
	private int id;
	private ArrayList<Node> genNode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ArrayList<Node> getGenNode() {
		return genNode;
	}

	public void setGenNode(ArrayList<Node> genNode) {
		this.genNode = genNode;
	}

	public Gen(int id, ArrayList<Node> genNode) {
		super();
		this.id = id;
		this.genNode = genNode;
	}

}
