package com.gamsond02.process;

public class Config {
	public static final int POPULATION = 300; // So ca the trong quan the
	public static final int GENERATION = 300; // So lan lap cua giai thuat di truyen
	public static final int NOCROSS = 30; // So ca the cha me mang ra lai ghep
	public static final int NOMUTANT = 30; // So ca the dot bien
//	public static final int NOMUTANT2 = 30; // So ca the dot bien
	public static final int NOGENERATION = 5;// So lan thuc hien voi bo du lieu
//	public static final String DATAFILE = "data/a6_4_2.txt";
	public static final String MYLAPTOP = "Configuration of your computer";

	public int getPOPULATION() {
		return POPULATION;
	}

	public int getGENERATION() {
		return GENERATION;
	}
}
