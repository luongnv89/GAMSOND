/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Dragoon
 */
public class Common {
    static public final int MAXCOST=9999999;
    static public final int MAX_PATH_NUMBER=10;
    static public final int RETRY=10;
    static public final int POPULATION=300;
    static public final int MUTANT_RATE=1000;
    static public final int NO_GENERATION=300;
    static public final int START=101;
    static public final int END=150;
    static public int TEST_DATA_NO=8;
    static public final String TEST_DATA="Atlanta";
}
